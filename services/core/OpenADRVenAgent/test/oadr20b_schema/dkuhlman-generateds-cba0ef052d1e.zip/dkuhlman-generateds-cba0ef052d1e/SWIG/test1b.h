/* File: test1b.h
*/

typedef struct Record4 {
	int species;
	unsigned long hairCount;
	char * description;
} * Record4Ptr;

